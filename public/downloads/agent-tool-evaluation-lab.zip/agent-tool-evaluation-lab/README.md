# Tool-calling evaluation laboratory

Original source supplied by Mateusz Kubaszek, 2026-10-16.
The six source/dependency files (lab0.py, agent_loop.py, scenarios.py, main.py,
pyproject.toml, uv.lock) are unchanged. Their hashes are in source-sha256.json.

The article displays an actual execution of lab0.app.run() on 2026-10-16.
lab-observed.json contains the real results/results_broken calls, final states,
metrics, package versions and provenance. lab-traces.json contains all 22 turns,
including raw model responses, parsed calls, tool responses and execution errors.
Patient data and reference scenarios are teaching fixtures.

Requirements: Apple silicon Mac (MLX), uv, Python >=3.14 as declared in
pyproject.toml. uv can provision the interpreter. The first run downloads models.

    uv sync
    uv run marimo edit lab0.py

To capture a new execution, preserving the original lab code and generation:

    uv run python capture-tool-evaluation.py --lab . --output lab-observed.json

The capture observes run_agent's inputs and outputs; it does not change prompts,
schemas, parsers, tool functions, generation defaults or the random seed.
This is a recorded pass for each parser, not a production performance estimate.

The evaluator in lab0.py defines five Record fixtures. The separate catalogue
in scenarios.py contains 20 scenarios and initial mocked tables.

Interpretation:
- Per-turn/per-tool scores compare presence of tool names.
- Scenario scores count repeated names, ignoring arguments and order.
- Attempted calls are counted even if their execution fails.
- Final-state checks cover selected fields and changes to other patients.
- Embedding similarity is illustrative, not a correctness criterion.
- Review the longest reference turn against the system prompt's requirement
  to look up records before each modifying call. Name scores do not enforce it.
- Correcting the parser does not fix the model's tool choices or skipped actions.

The article highlights Happy path, turn 2, patient 12345: the broken parser
merges lab_name into get_patient_status and loses assign_patient_labs.
Its original TypeError and the model's following reply are in the trace.
