"""Minimal agent loop: model decides -> call a tool -> return the result to the model -> repeat."""

import ast
import re
from typing import Any, Callable

from mlx_lm import generate
from transformers.utils.chat_template_utils import get_json_schema


def parse_tool_calls(text: str) -> list[tuple[str, dict[str, str]]]:
    """'[a(x="1"), b(y=2)]' -> [('a', {'x': '1'}), ('b', {'y': '2'})]

    LFM2 returns calls as a Python-style list. Parsing with ast handles parentheses and commas inside strings.
    """
    match = re.search(r"\[\s*[a-zA-Z_]\w*\(.*\)\s*\]", text, re.S)
    if not match:
        return []
    try:
        calls = ast.parse(match.group(), mode="eval").body.elts
        return [(c.func.id, {kw.arg: str(ast.literal_eval(kw.value)) for kw in c.keywords}) for c in calls]
    except (SyntaxError, ValueError, AttributeError):
        return []


def format_tools(tools: list[Callable]) -> list[dict[str, Any]]:
    """Convert Python functions to JSON schemas for the chat template, without the 'return' field."""
    schemas = []
    for tool in tools:
        schema = get_json_schema(tool)["function"]
        schema.pop("return", None)
        schemas.append(schema)
    return schemas


def run_agent(
    messages: list[dict[str, str]], tools: list[Callable], model, tokenizer, max_steps: int = 5, parse=parse_tool_calls
) -> list[tuple[str, dict]]:
    """Handle one user turn: append steps to `messages` and return the tool calls."""
    tools_map = {t.__name__: t for t in tools}
    schemas = format_tools(tools)
    calls = []
    for _ in range(max_steps):
        prompt = tokenizer.apply_chat_template(messages, tools=schemas, add_generation_prompt=True, tokenize=False)
        response = generate(model, tokenizer, prompt, max_tokens=256)  # Multiple calls can exceed 120 tokens.
        messages.append({"role": "assistant", "content": response})
        new_calls = parse(response)
        if not new_calls:
            return calls  # A text response without tool calls ends the turn.
        for name, args in new_calls:
            calls.append((name, args))
            try:
                result = tools_map[name](**args)
            except Exception as e:  # Return unknown tools or invalid arguments to the model as observations.
                result = f"Error: {e!r}"
            messages.append({"role": "tool", "content": str(result)})
    return calls


if __name__ == "__main__":
    assert parse_tool_calls('<|tool_call_start|>[get_patient_status(patient_id="12345")]<|tool_call_end|>') == [
        ("get_patient_status", {"patient_id": "12345"})
    ]
    assert parse_tool_calls('[search_patient_data(query="12345"), assign_patient_labs(lab_name="ECG", patient_id=12345)]') == [
        ("search_patient_data", {"query": "12345"}),
        ("assign_patient_labs", {"lab_name": "ECG", "patient_id": "12345"}),
    ]
    assert parse_tool_calls('[assign_patient_surgery(surgery_name="Appendectomy (appendix removal)", patient_id="1")]') == [
        ("assign_patient_surgery", {"surgery_name": "Appendectomy (appendix removal)", "patient_id": "1"})
    ]
    assert parse_tool_calls("Lab assigned for patient 12345.") == []
    print("parse_tool_calls ok")
