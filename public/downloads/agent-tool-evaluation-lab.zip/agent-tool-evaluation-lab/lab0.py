import marimo

__generated_with = "0.25.1"
app = marimo.App(width="medium")


@app.cell
def _():
    import json
    import re
    from copy import deepcopy
    from dataclasses import dataclass

    import marimo as mo
    from mlx_lm import load
    from sklearn.metrics import classification_report, confusion_matrix, multilabel_confusion_matrix

    from agent_loop import parse_tool_calls, run_agent
    from scenarios import EXTENDED_PATIENT_TABLE as patient_table, EXTENDED_STATUS_TABLE

    return (
        EXTENDED_STATUS_TABLE,
        classification_report,
        confusion_matrix,
        dataclass,
        deepcopy,
        json,
        load,
        mo,
        multilabel_confusion_matrix,
        parse_tool_calls,
        patient_table,
        re,
        run_agent,
    )


@app.cell
def _(mo):
    mo.md(r"""
    # Evaluating a tool-calling agent

    Each scenario contains user turns, expected tool calls and an expected final patient state.
    We reset the data, run the conversation and compare the results with this golden set.

    - **Precision** = TP / (TP + FP): how many calls were expected?
    - **Recall** = TP / (TP + FN): how many expected calls were made?
    - **F1** = 2 × precision × recall / (precision + recall).
    - **Final-state score**: the fraction of expected fields that match exactly.
    - **Embedding similarity**: an illustration, not a correctness check.

    Per-turn and per-tool scores measure tool presence. Scenario scores also count repeated calls.
    These scores compare tool names, not arguments or call order; the final state checks the effects.
    Undefined ratios are reported as 0. Changes to other patients are checked separately.
    """)
    return


@app.cell
def _(load):
    model, tokenizer = load("LiquidAI/LFM2-1.2B-Tool")
    return model, tokenizer


@app.cell
def _(EXTENDED_STATUS_TABLE, deepcopy):
    # Tools change state; evaluate() resets this copy before each scenario.
    status_table = deepcopy(EXTENDED_STATUS_TABLE)
    return (status_table,)


@app.cell
def _(json, patient_table, status_table):
    def find_patient(query: str) -> str | None:
        """Resolve an ID, REQ-... request number, PESEL or part of a name to a patient ID."""
        q = str(query).strip().lower()
        for pid, p in patient_table.items():
            if q and (q in (pid, status_table[pid]["request_id"].lower(), p["pesel"]) or q in p["name"].lower()):
                return pid
        return None

    def get_patient_status(patient_id: str) -> str:
        """Retrieves the current status of a patient in the assignment process.

        Args:
            patient_id: Unique identifier for the patient.
        """
        pid = find_patient(patient_id)
        return json.dumps(status_table[pid], ensure_ascii=False) if pid else f"Patient with ID {patient_id} not found."

    def search_patient_data(query: str) -> str:
        """Retrieves patient information and medical history based on search query.

        Args:
            query: Query string to search patient records.
        """
        pid = find_patient(query)
        return json.dumps(patient_table[pid], ensure_ascii=False) if pid else f"No patient records found matching query: '{query}'"

    def approve_patient_request(query: str) -> bool:
        """Approves a patient request in the healthcare system.

        Args:
            query: Unique identifier or details of the patient request to approve.
        """
        pid = find_patient(query)
        if not pid:
            return False
        status_table[pid].update(admission_approved=True, current_status="Admitted to ward")
        return True

    def assign_patient_labs(lab_name: str, patient_id: str) -> bool:
        """Assigns laboratory tests for a patient.

        Args:
            lab_name: Name of the laboratory test to assign.
            patient_id: Unique identifier for the patient.
        """
        pid = find_patient(patient_id)
        if not pid:
            return False
        status_table[pid]["assigned_labs"].append(lab_name.strip())
        status_table[pid]["labs_status"] = "Tests ordered"
        return True

    def assign_patient_surgery(surgery_name: str, patient_id: str) -> bool:
        """Assigns surgery for a patient.

        Args:
            surgery_name: Name of the surgery to assign.
            patient_id: Unique identifier for the patient.
        """
        pid = find_patient(patient_id)
        if not pid:
            return False
        status_table[pid].update(assigned_surgery=surgery_name, surgery_status="Assigned", current_status="Surgery assigned")
        return True

    tools = [get_patient_status, search_patient_data, approve_patient_request, assign_patient_labs, assign_patient_surgery]
    return (tools,)


@app.cell
def _(dataclass):
    @dataclass(frozen=True)
    class Turn:
        prompt: str  # English prompts are more reliable with LFM2-1.2B.
        expected_calls: list[tuple[str, dict]]  # Ordered (tool name, arguments) pairs, as returned by run_agent.

    @dataclass(frozen=True)
    class Record:
        name: str
        patient_id: str
        turns: list[Turn]  # Consecutive turns in one conversation.
        snapshot: dict  # Expected patient state after the last turn.

    goldenset = [
        Record(
            name="Happy path: admission -> labs -> surgery",
            patient_id="12345",
            turns=[
                Turn(
                    "Patient John Smith (ID 12345) arrived at the admissions desk. Check the medical records of patient 12345 first, then please approve patient request REQ-12345.",
                    [
                        ("search_patient_data", {"query": "12345"}),
                        ("approve_patient_request", {"query": "REQ-12345"}),
                    ],
                ),
                Turn(
                    "Check the medical records of patient 12345 first, then assign lab CBC for patient 12345.",
                    [
                        ("search_patient_data", {"query": "12345"}),
                        ("assign_patient_labs", {"lab_name": "CBC", "patient_id": "12345"}),
                    ],
                ),
                Turn(
                    "Check the medical records of patient 12345 first, then assign surgery Appendectomy for patient 12345.",
                    [
                        ("search_patient_data", {"query": "12345"}),
                        ("assign_patient_surgery", {"surgery_name": "Appendectomy", "patient_id": "12345"}),
                    ],
                ),
            ],
            snapshot={"admission_approved": True, "assigned_labs": ["CBC"], "assigned_surgery": "Appendectomy"},
        ),
        Record(
            name="Already on the ward: no repeated approval",
            patient_id="12346",
            turns=[
                Turn(
                    "Patient 12346 is already on the ward. Check her current status.",
                    [("get_patient_status", {"patient_id": "12346"})],
                ),
                Turn(
                    "Check the medical records of patient 12346 first, then assign lab Liver function tests for patient 12346.",
                    [
                        ("search_patient_data", {"query": "12346"}),
                        ("assign_patient_labs", {"lab_name": "Liver function tests", "patient_id": "12346"}),
                    ],
                ),
                Turn(
                    "Check the medical records of patient 12346 first, then assign surgery Laparoscopic cholecystectomy for patient 12346.",
                    [
                        ("search_patient_data", {"query": "12346"}),
                        ("assign_patient_surgery", {"surgery_name": "Laparoscopic cholecystectomy", "patient_id": "12346"}),
                    ],
                ),
            ],
            snapshot={
                "admission_approved": True,
                "assigned_labs": ["CBC", "Coagulation panel", "Blood typing", "Liver function tests"],
                "assigned_surgery": "Laparoscopic cholecystectomy",
            },
        ),
        Record(
            name="Senior patient: tests before admission",
            patient_id="12349",
            turns=[
                Turn(
                    "Patient 12349 is 68 and needs a cardiac check before admission. Check the medical records of patient 12349 first, then assign lab ECG for patient 12349.",
                    [
                        ("search_patient_data", {"query": "12349"}),
                        ("assign_patient_labs", {"lab_name": "ECG", "patient_id": "12349"}),
                    ],
                ),
                Turn(
                    "ECG is normal. Check the medical records of patient 12349 first, then please approve patient request REQ-12349.",
                    [
                        ("search_patient_data", {"query": "12349"}),
                        ("approve_patient_request", {"query": "REQ-12349"}),
                    ],
                ),
                Turn(
                    "Check the medical records of patient 12349 first, then assign surgery Cholecystectomy for patient 12349.",
                    [
                        ("search_patient_data", {"query": "12349"}),
                        ("assign_patient_surgery", {"surgery_name": "Cholecystectomy", "patient_id": "12349"}),
                    ],
                ),
            ],
            snapshot={"admission_approved": True, "assigned_labs": ["ECG"], "assigned_surgery": "Cholecystectomy"},
        ),
        Record(
            name="On hold: incomplete documentation",
            patient_id="12350",
            turns=[
                Turn(
                    "Check the status of patient 12350. If the documentation is incomplete, do not approve admission or assign surgery.",
                    [("get_patient_status", {"patient_id": "12350"})],
                ),
            ],
            snapshot={"admission_approved": False, "assigned_labs": [], "assigned_surgery": None},
        ),
        Record(
            name="Full workflow: status after each step",
            patient_id="12346",
            turns=[
                Turn(
                    "Get the medical records of patient 12346 and check her status. Then assign lab Liver function tests for patient 12346 "
                    "and check her status. Then assign surgery Laparoscopic cholecystectomy for patient 12346 and check her status.",
                    [
                        ("search_patient_data", {"query": "12346"}),
                        ("get_patient_status", {"patient_id": "12346"}),
                        ("assign_patient_labs", {"lab_name": "Liver function tests", "patient_id": "12346"}),
                        ("get_patient_status", {"patient_id": "12346"}),
                        ("assign_patient_surgery", {"surgery_name": "Laparoscopic cholecystectomy", "patient_id": "12346"}),
                        ("get_patient_status", {"patient_id": "12346"}),
                    ],
                ),
            ],
            snapshot={
                "admission_approved": True,
                "assigned_labs": ["CBC", "Coagulation panel", "Blood typing", "Liver function tests"],
                "assigned_surgery": "Laparoscopic cholecystectomy",
            },
        ),
    ]
    return (goldenset,)


@app.cell
def _():
    from sentence_transformers import SentenceTransformer

    model_sentence = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    return (model_sentence,)


@app.cell
def _(model_sentence):
    from collections import Counter
    from itertools import zip_longest

    def tool_names(calls):
        return [name for name, _ in calls]

    def score_tools(expected, actual):
        """Count matching, extra and missing tool names, including repeated calls."""
        expected, actual = Counter(expected), Counter(actual)
        tp = sum((actual & expected).values())
        fp = sum((actual - expected).values())
        fn = sum((expected - actual).values())
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        return {"tp": tp, "fp": fp, "fn": fn, "precision": precision, "recall": recall, "f1": f1}

    def similarity(actual, expected):
        embeddings = model_sentence.encode([str(actual), str(expected)])
        return float(model_sentence.similarity(embeddings, embeddings)[0, 1])

    def md_table(header, rows):
        lines = ["| " + " | ".join(header) + " |", "|" + ":---|" * len(header)]
        return "\n".join(lines + ["| " + " | ".join(str(cell) for cell in row) + " |" for row in rows])

    return Counter, md_table, score_tools, similarity, tool_names, zip_longest


@app.cell
def _(EXTENDED_STATUS_TABLE, deepcopy, model, parse_tool_calls, run_agent, status_table, tokenizer, tools):
    system_prompt = (
        "You are a hospital admissions agent. Before you call approve_patient_request, assign_patient_labs "
        "or assign_patient_surgery, always call search_patient_data with the patient ID first."
    )
    tools_map = {t.__name__: t for t in tools}

    def evaluate(record, parse=parse_tool_calls, trajectory=None):
        """Run a scenario, or replay supplied calls without using the model."""
        status_table.clear()
        status_table.update(deepcopy(EXTENDED_STATUS_TABLE))
        messages = [{"role": "system", "content": system_prompt}]
        turn_calls = []
        for i, turn in enumerate(record.turns):
            messages.append({"role": "user", "content": turn.prompt})
            if trajectory is None:
                # The longest golden-set turn needs six calls.
                calls = run_agent(messages, tools, model, tokenizer, max_steps=8, parse=parse)
            else:
                calls = trajectory[i]
                for name, args in calls:
                    tools_map[name](**args)
            turn_calls.append(calls)

        state = status_table[record.patient_id]
        snapshot = {k: state[k] for k in record.snapshot}
        # The target snapshot alone cannot detect changes to another patient.
        no_side_effects = all(status_table[p] == EXTENDED_STATUS_TABLE[p] for p in status_table if p != record.patient_id)
        return turn_calls, snapshot, no_side_effects

    return (evaluate,)


@app.cell
def _(Counter, classification_report, confusion_matrix, md_table, mo, multilabel_confusion_matrix, score_tools, similarity, tool_names, tools, zip_longest):
    def scenario_report(record, turn_calls, snapshot, no_side_effects, threshold):
        turn_rows = []
        for i, (turn, calls) in enumerate(zip(record.turns, turn_calls), 1):
            # Sets measure presence; repeated calls are counted in the scenario score below.
            scores = score_tools(set(tool_names(turn.expected_calls)), set(tool_names(calls)))
            turn_rows.append([
                i, turn.prompt, f"`{calls}`", f"`{turn.expected_calls}`",
                f"{scores['precision']:.2f}", f"{scores['recall']:.2f}", f"{scores['f1']:.2f}",
                f"{similarity(calls, turn.expected_calls):.2f}",
            ])

        actual = Counter(name for calls in turn_calls for name in tool_names(calls))
        expected = Counter(name for turn in record.turns for name in tool_names(turn.expected_calls))
        scores = score_tools(expected, actual)
        matched = sum(snapshot[k] == v for k, v in record.snapshot.items())
        final = matched / len(record.snapshot)
        snapshot_similarity = similarity(snapshot, record.snapshot)
        snapshot_rows = [[k, f"`{snapshot[k]}`", f"`{v}`", snapshot[k] == v] for k, v in record.snapshot.items()]

        details = "\n\n".join([
            "**Turns (tool presence)**",
            md_table(["#", "Prompt", "Actual calls", "Expected calls", "Precision", "Recall", "F1", "Similarity"], turn_rows),
            "**Scenario counts (including repeated calls)**",
            f"Actual: `{dict(actual)}`  \nExpected: `{dict(expected)}`",
            f"Missing: `{dict(expected - actual)}`  \nExtra: `{dict(actual - expected)}`",
            md_table(["TP", "FP", "FN", "Precision", "Recall", "F1"], [[
                scores["tp"], scores["fp"], scores["fn"],
                f"{scores['precision']:.2f}", f"{scores['recall']:.2f}", f"{scores['f1']:.2f}",
            ]]),
            "**Final state**",
            md_table(["Field", "Actual", "Expected", "Match"], snapshot_rows),
            f"Final-state score: {matched}/{len(record.snapshot)} = {final:.2f}  \n"
            f"Embedding similarity: {snapshot_similarity:.2f}  \nOther patients unchanged: {no_side_effects}",
        ])
        title = f"{record.name} · F1 {scores['f1']:.2f} · final state {final:.2f}"
        row = [
            record.name, actual == expected, scores["tp"], scores["fp"], scores["fn"],
            f"{scores['precision']:.2f}", f"{scores['recall']:.2f}", f"{scores['f1']:.2f}",
            f"{final:.2f}", f"{snapshot_similarity:.2f}", no_side_effects,
        ]
        return title, details, row, (actual == expected, final >= threshold)

    def report(records, results, title, threshold=0.85):
        scenarios = [scenario_report(record, *result, threshold) for record, result in zip(records, results)]
        quadrants = {}  # (tool counts match?, final-state score >= threshold?) -> scenario names
        for record, (_, _, _, key) in zip(records, scenarios):
            quadrants.setdefault(key, []).append(record.name)

        expected_turns = [tool_names(turn.expected_calls) for record in records for turn in record.turns]
        actual_turns = [tool_names(calls) for turn_calls, _, _ in results for calls in turn_calls]
        # Unknown tool names must also count as false positives.
        labels = list(dict.fromkeys([tool.__name__ for tool in tools] + [name for turn in actual_turns for name in turn]))
        y_true = [[int(label in turn) for label in labels] for turn in expected_turns]
        y_pred = [[int(label in turn) for label in labels] for turn in actual_turns]
        stats = classification_report(y_true, y_pred, target_names=labels, zero_division=0, output_dict=True)
        tool_rows = []
        for label, ((tn, fp), (fn, tp)) in zip(labels, multilabel_confusion_matrix(y_true, y_pred)):
            s = stats[label]
            tool_rows.append([label, tp, fp, fn, tn, f"{s['precision']:.2f}", f"{s['recall']:.2f}", f"{s['f1-score']:.2f}", int(s["support"])])
        for average in ("micro avg", "macro avg"):
            s = stats[average]
            tool_rows.append([average, "", "", "", "", f"{s['precision']:.2f}", f"{s['recall']:.2f}", f"{s['f1-score']:.2f}", int(s["support"])])

        pairs = []
        for expected, actual in zip(expected_turns, actual_turns):
            expected, actual = Counter(expected), Counter(actual)
            pairs.extend((name, name) for name in (actual & expected).elements())
            # Pair missing names with extra names; '-' marks an unmatched call.
            pairs.extend(zip_longest((expected - actual).elements(), (actual - expected).elements(), fillvalue="-"))
        names = labels + ["-"]
        matrix = confusion_matrix([e for e, _ in pairs], [a for _, a in pairs], labels=names)
        matrix_rows = [
            [name, *(f"**{value}**" if value and i != j else value for j, value in enumerate(row))]
            for i, (name, row) in enumerate(zip(names, matrix))
        ]

        summary = "\n\n".join([
            f"## {title}",
            "### Scenarios",
            md_table(
                ["Scenario", "Tool counts match", "TP", "FP", "FN", "Precision", "Recall", "F1", "Final state", "Snapshot similarity", "Other patients unchanged"],
                [row for _, _, row, _ in scenarios],
            ),
            f"### Tool counts vs final-state score (threshold {threshold})",
            md_table(["", "At or above threshold", "Below threshold"], [
                [label, len(quadrants.get((ok, True), [])), len(quadrants.get((ok, False), []))]
                for ok, label in ((True, "Matching tool counts"), (False, "Different tool counts"))
            ]),
            f"**Good final state despite different tool counts:** {', '.join(quadrants.get((False, True), [])) or 'none'}",
            f"### Per-tool confusion matrices ({len(actual_turns)} turns, presence only)",
            "TP: expected and called; FP: called but not expected; FN: expected but not called; TN: neither expected nor called.",
            md_table(["Tool", "TP", "FP", "FN", "TN", "Precision", "Recall", "F1", "Support"], tool_rows),
            "### Expected tool (row) vs actual tool (column)",
            "Bold values mark off-diagonal errors. `-` marks a missing or extra call. "
            "Missing and extra names are paired in order, not aligned by arguments or call position.",
            md_table(["Expected / actual", *names], matrix_rows),
            "### Scenario details",
        ])
        return mo.vstack([mo.md(summary), mo.accordion({t: mo.md(d) for t, d, _, _ in scenarios})])

    return (report,)


@app.cell
def _(evaluate, goldenset):
    results = [evaluate(record) for record in goldenset]
    return (results,)


@app.cell
def _(goldenset, report, results):
    report(goldenset, results, "Correct parser")
    return


@app.cell
def _(evaluate, goldenset, mo, report):
    full_path = goldenset[-1]  # Records -> status -> labs -> status -> surgery -> status.
    # Skip the first status check: this read-only call cannot change the final state.
    skipped_check = [[call for i, call in enumerate(full_path.turns[0].expected_calls) if i != 1]]
    mo.vstack([
        mo.md("""
        ## Same workflow, one fewer status check
        The golden set expects: patient records -> status -> labs -> status -> surgery -> status.
        Without the model, we replay: patient records -> labs -> status -> surgery -> status.
        Scenario recall and F1 drop because one call is missing, but the final state is identical:
        `get_patient_status` is read-only. Presence scores stay unchanged because the tool is still called.
        """),
        report([full_path], [evaluate(full_path, trajectory=skipped_check)], "Replayed trajectory vs golden set"),
    ])
    return


@app.cell
def _(re):
    def parse_tool_calls_broken(text: str) -> list[tuple[str, dict[str, str]]]:
        """Intentionally broken exercise: compare its matrices with parse_tool_calls and find the bug."""
        match = re.search(r"\[([a-zA-Z_]\w*)\((.*?)\)\]", text)
        if not match:
            return []
        name, args_str = match.groups()
        return [(name, {k: v1 or v2 for k, v1, v2 in re.findall(r"(\w+)\s*=\s*(?:['\"](.*?)['\"]|([^\s,]+))", args_str)})]

    return (parse_tool_calls_broken,)


@app.cell
def _(evaluate, goldenset, parse_tool_calls_broken):
    results_broken = [evaluate(record, parse=parse_tool_calls_broken) for record in goldenset]
    return (results_broken,)


@app.cell
def _(goldenset, mo, report, results_broken):
    mo.vstack([
        mo.md("""
        ## Exercise: find the bug
        Run the same evaluation with `parse_tool_calls_broken`.
        Compare its matrices with the correct parser: which rows changed, and what does that suggest about the bug?
        """),
        report(goldenset, results_broken, "Broken parser"),
    ])
    return


if __name__ == "__main__":
    app.run()
