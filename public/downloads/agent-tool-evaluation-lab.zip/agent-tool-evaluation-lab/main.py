import lab0

if __name__ == "__main__":
    lab0.app.run()
