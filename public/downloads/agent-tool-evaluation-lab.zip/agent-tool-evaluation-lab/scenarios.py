"""Twenty conversational scenarios for surgical assessment and patient approval.

The scenarios model this workflow:
Patient arrives -> data retrieval/verification -> test ordering / analysis -> surgical approval / surgery assignment,
with 20 distinct clinical and organizational permutations.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Turn:
    turn_id: int
    user_prompt: str
    expected_tools: List[str]
    description: str
    expected_args: Optional[Dict[str, Any]] = None


@dataclass
class Scenario:
    id: int
    name: str
    description: str
    permutation_type: str
    patient_id: str
    turns: List[Turn] = field(default_factory=list)


# Extended patient and status database for 20 distinct scenarios
EXTENDED_STATUS_TABLE: Dict[str, Dict[str, Any]] = {
    "12345": {
        "patient_id": "12345",
        "request_id": "REQ-12345",
        "current_status": "Awaiting ward admission",
        "admission_approved": False,
        "target_ward": "General Surgery Ward",
        "current_ward": None,
        "bed_assigned": None,
        "labs_status": "Awaiting orders",
        "assigned_labs": [],
        "surgery_status": "Unassigned",
        "assigned_surgery": None,
        "notes": "Admission request submitted at the admissions unit; awaiting approval and admission to the surgical ward.",
    },
    "12346": {
        "patient_id": "12346",
        "request_id": "REQ-12346",
        "current_status": "Admitted to ward",
        "admission_approved": True,
        "target_ward": "General Surgery Ward",
        "current_ward": "General Surgery Ward",
        "bed_assigned": "Room 204, Bed 2",
        "labs_status": "Tests ordered",
        "assigned_labs": ["CBC", "Coagulation panel", "Blood typing"],
        "surgery_status": "Awaiting surgery assignment",
        "assigned_surgery": None,
        "notes": "Patient admitted to the surgical ward, laboratory tests ordered, awaiting surgical assessment.",
    },
    "12347": {
        "patient_id": "12347",
        "request_id": "REQ-12347",
        "current_status": "Surgery assigned",
        "admission_approved": True,
        "target_ward": "General Surgery Ward",
        "current_ward": "General Surgery Ward",
        "bed_assigned": "Room 205, Bed 1",
        "labs_status": "Tests completed",
        "assigned_labs": ["CBC", "Electrolytes", "ECG"],
        "surgery_status": "Assigned",
        "assigned_surgery": "Inguinal hernia repair",
        "notes": "Patient admitted, tests completed, surgery successfully assigned and scheduled.",
    },
    "12348": {
        "patient_id": "12348",
        "request_id": "REQ-12348",
        "current_status": "Awaiting diagnostic workup",
        "admission_approved": False,
        "target_ward": "General Surgery Ward",
        "current_ward": None,
        "bed_assigned": None,
        "labs_status": "No tests",
        "assigned_labs": [],
        "surgery_status": "Unassigned",
        "assigned_surgery": None,
        "notes": "Patient presenting for elective admission with missing laboratory documentation.",
    },
    "12349": {
        "patient_id": "12349",
        "request_id": "REQ-12349",
        "current_status": "Geriatric assessment",
        "admission_approved": False,
        "target_ward": "General Surgery Ward",
        "current_ward": None,
        "bed_assigned": None,
        "labs_status": "Extended panel required",
        "assigned_labs": [],
        "surgery_status": "Unassigned",
        "assigned_surgery": None,
        "notes": "Patient aged 68, elective surgery planned, cardiac assessment required (ECG, electrolytes).",
    },
    "12350": {
        "patient_id": "12350",
        "request_id": "REQ-12350",
        "current_status": "Incomplete documentation",
        "admission_approved": False,
        "target_ward": "General Surgery Ward",
        "current_ward": None,
        "bed_assigned": None,
        "labs_status": "No tests",
        "assigned_labs": [],
        "surgery_status": "On hold",
        "assigned_surgery": None,
        "notes": "Request missing the specialist referral; assessment on hold.",
    },
    "12351": {
        "patient_id": "12351",
        "request_id": "REQ-12351",
        "current_status": "Anticoagulant medication review",
        "admission_approved": False,
        "target_ward": "General Surgery Ward",
        "current_ward": None,
        "bed_assigned": None,
        "labs_status": "Awaiting INR check",
        "assigned_labs": [],
        "surgery_status": "Unassigned",
        "assigned_surgery": None,
        "notes": "Patient taking oral anticoagulants; blood coagulation assessment required.",
    },
}

EXTENDED_PATIENT_TABLE: Dict[str, Dict[str, Any]] = {
    "12345": {
        "patient_id": "12345",
        "name": "John Smith",
        "age": 45,
        "gender": "M",
        "pesel": "79051412345",
        "admission_request": {
            "request_id": "REQ-12345",
            "department": "General Surgery Ward",
            "admission_type": "Urgent",
            "referral_reason": "Suspected acute appendicitis",
            "referring_doctor": "Dr Adam Brown",
        },
        "diagnosis": "Acute appendicitis",
        "recommended_surgery": "Appendectomy",
        "required_labs": [
            "CBC",
            "Blood typing",
            "Coagulation panel (PT, INR, APTT)",
            "Electrolytes (Na, K)",
        ],
        "medical_history": "No significant chronic conditions, no previous surgery, no drug allergies.",
    },
    "12346": {
        "patient_id": "12346",
        "name": "Anna Brown",
        "age": 52,
        "gender": "F",
        "pesel": "72031123456",
        "admission_request": {
            "request_id": "REQ-12346",
            "department": "General Surgery Ward",
            "admission_type": "Elective",
            "referral_reason": "Symptomatic cholelithiasis",
            "referring_doctor": "Dr Eve Clark",
        },
        "diagnosis": "Cholelithiasis",
        "recommended_surgery": "Laparoscopic cholecystectomy",
        "required_labs": [
            "CBC",
            "Coagulation panel",
            "Liver function tests (ALT, AST, bilirubin)",
            "Blood typing",
        ],
        "medical_history": "Medication-controlled hypertension, pollen allergy, no drug allergies.",
    },
    "12347": {
        "patient_id": "12347",
        "name": "Peter Williams",
        "age": 38,
        "gender": "M",
        "pesel": "86082234567",
        "admission_request": {
            "request_id": "REQ-12347",
            "department": "General Surgery Ward",
            "admission_type": "Elective",
            "referral_reason": "Right inguinal hernia",
            "referring_doctor": "Dr John Williams",
        },
        "diagnosis": "Inguinal hernia",
        "recommended_surgery": "Inguinal hernia repair",
        "required_labs": [
            "CBC",
            "Electrolytes",
            "ECG",
        ],
        "medical_history": "Good general condition, no chronic conditions or allergies.",
    },
    "12348": {
        "patient_id": "12348",
        "name": "Mark Davis",
        "age": 41,
        "gender": "M",
        "pesel": "83021956789",
        "admission_request": {
            "request_id": "REQ-12348",
            "department": "General Surgery Ward",
            "admission_type": "Elective",
            "referral_reason": "Epigastric hernia",
            "referring_doctor": "Dr Thomas Green",
        },
        "diagnosis": "Abdominal hernia (Epigastric hernia)",
        "recommended_surgery": "Epigastric hernia repair",
        "required_labs": ["CBC", "Coagulation panel"],
        "medical_history": "No significant medical history, no allergies.",
    },
    "12349": {
        "patient_id": "12349",
        "name": "Theodore Lewis",
        "age": 68,
        "gender": "M",
        "pesel": "56041189012",
        "admission_request": {
            "request_id": "REQ-12349",
            "department": "General Surgery Ward",
            "admission_type": "Elective",
            "referral_reason": "Symptomatic gallstones in an older patient",
            "referring_doctor": "Dr Mary Wright",
        },
        "diagnosis": "Chronic gallstone disease",
        "recommended_surgery": "Cholecystectomy",
        "required_labs": ["ECG", "Electrolytes", "CBC"],
        "medical_history": "Stable ischemic heart disease, hypertension.",
    },
    "12350": {
        "patient_id": "12350",
        "name": "Christopher Dawson",
        "age": 29,
        "gender": "M",
        "pesel": "95070312389",
        "admission_request": {
            "request_id": "REQ-12350",
            "department": "General Surgery Ward",
            "admission_type": "Elective",
            "referral_reason": "Consultation and assessment",
            "referring_doctor": "Unknown",
        },
        "diagnosis": "Right lower abdominal pain requiring diagnostic workup",
        "recommended_surgery": "To be determined after testing",
        "required_labs": ["Abdominal ultrasound", "CBC"],
        "medical_history": "No formal referral in the documentation.",
    },
    "12351": {
        "patient_id": "12351",
        "name": "Stanley Wilson",
        "age": 63,
        "gender": "M",
        "pesel": "61091567890",
        "admission_request": {
            "request_id": "REQ-12351",
            "department": "General Surgery Ward",
            "admission_type": "Elective",
            "referral_reason": "Assessment for cholecystectomy while on anticoagulant therapy",
            "referring_doctor": "Dr Andrew Carter",
        },
        "diagnosis": "Cholelithiasis, atrial fibrillation",
        "recommended_surgery": "Laparoscopic cholecystectomy",
        "required_labs": ["Coagulation panel PT, INR", "CBC", "Electrolytes"],
        "medical_history": "Taking warfarin for atrial fibrillation. INR measurement required.",
    },
}


SCENARIOS_DATABASE: List[Scenario] = [
    # 1. Standard elective assessment (Happy Path)
    Scenario(
        id=1,
        name="Standard elective assessment (Happy path)",
        description="Patient presents with ID 12345. The agent checks status, retrieves medical data, approves request REQ-12345 and assigns an appendectomy.",
        permutation_type="ID -> Status -> Medical data -> Approve -> Surgery assignment",
        patient_id="12345",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="A patient has arrived at the admissions unit; his ID is 12345. Check the patient's current status.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "12345"},
                description="Identify the patient and check admission status.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Retrieve medical data for patient John Smith before assessment.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "John Smith"},
                description="Retrieve the medical record and surgical indications.",
            ),
            Turn(
                turn_id=3,
                user_prompt="The patient's condition is confirmed. Please approve patient request REQ-12345.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12345"},
                description="Authorize admission to the General Surgery Ward.",
            ),
            Turn(
                turn_id=4,
                user_prompt="Assign surgery Appendectomy for patient 12345.",
                expected_tools=["assign_patient_surgery"],
                expected_args={"surgery_name": "Appendectomy", "patient_id": "12345"},
                description="Officially schedule the surgical procedure.",
            ),
        ],
    ),

    # 2. Presentation by name (no patient ID)
    Scenario(
        id=2,
        name="Find a patient by name",
        description="A patient arrives without her card and does not know her ID. The agent searches for Anna Brown's record by name, checks the referral and approves admission.",
        permutation_type="Name -> Search -> Approve",
        patient_id="12346",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Patient Anna Brown has arrived without an ID number. Find her medical record.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "Anna Brown"},
                description="Find the patient's data in the system using a text query.",
            ),
            Turn(
                turn_id=2,
                user_prompt="The diagnosis is cholelithiasis. Approve the admission request for patient Anna Brown.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "Anna Brown"},
                description="Approve the request after confirming identity.",
            ),
        ],
    ),

    # 3. Urgent presentation (emergency duty / emergency department)
    Scenario(
        id=3,
        name="Urgent emergency presentation (ED)",
        description="An urgent patient with suspected acute appendicitis. Immediate data verification and urgent approval.",
        permutation_type="Urgent presentation -> Data -> Immediate approval",
        patient_id="12345",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="An urgent patient reports acute abdominal pain, ID 12345. Check the referral and diagnosis.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "12345"},
                description="Verify the urgency of the surgical indications.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Acute appendicitis has been confirmed. Immediately approve patient 12345 for admission to the operating suite.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "12345"},
                description="Prioritize authorization of surgical admission.",
            ),
        ],
    ),

    # 4. Missing laboratory tests before surgery
    Scenario(
        id=4,
        name="Order missing laboratory tests before approval",
        description="Patient Mark Davis (12348) does not have a complete set of tests. The agent checks requirements, orders CBC and a coagulation panel, then approves the request.",
        permutation_type="Data retrieval -> Test ordering -> Approve",
        patient_id="12348",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Patient Mark Davis presents for assessment. Retrieve his medical data and required tests.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "Mark Davis"},
                description="Identify missing preoperative tests.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Order the required laboratory tests: CBC, Coagulation panel for patient 12348.",
                expected_tools=["assign_patient_labs"],
                expected_args={"lab_name": "CBC, Coagulation panel", "patient_id": "12348"},
                description="Order a laboratory test panel.",
            ),
            Turn(
                turn_id=3,
                user_prompt="The tests have been successfully ordered. Now approve the admission request for patient 12348.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "12348"},
                description="Approve admission after arranging diagnostic testing.",
            ),
        ],
    ),

    # 5. Patient with completed tests (direct assessment)
    Scenario(
        id=5,
        name="Completed laboratory tests - immediate assessment",
        description="Patient Peter Williams (12347) has completed-test status. The agent verifies status and approves the request without delay.",
        permutation_type="Status -> Completed-test verification -> Approve",
        patient_id="12347",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Check the current status of patient 12347 and the status of his laboratory tests.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "12347"},
                description="Confirm that test results are complete.",
            ),
            Turn(
                turn_id=2,
                user_prompt="All tests are complete. Approve request REQ-12347 for hernia repair.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12347"},
                description="Authorize the procedure with all diagnostic testing complete.",
            ),
        ],
    ),

    # 6. Identification by PESEL number
    Scenario(
        id=6,
        name="Patient identification by PESEL number",
        description="The patient identifies herself using PESEL number 72031123456. The agent retrieves data, identifies Anna Brown and approves the request.",
        permutation_type="PESEL -> Search -> Approve",
        patient_id="12346",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="The patient provided PESEL number 72031123456 at registration. Find her records in the database.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "72031123456"},
                description="Find the unique record by PESEL number.",
            ),
            Turn(
                turn_id=2,
                user_prompt="The data matches (Anna Brown). Approve admission request REQ-12346.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12346"},
                description="Approve the request associated with the identified PESEL number.",
            ),
        ],
    ),

    # 7. Identification by REQ request number
    Scenario(
        id=7,
        name="Identification by REQ request number",
        description="The operating surgeon provides request ID REQ-12345. The agent reads the status, checks patient data and approves surgery.",
        permutation_type="REQ-ID -> Status -> Medical data -> Approve",
        patient_id="12345",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Check the status of admission request REQ-12345.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "REQ-12345"},
                description="Verify the current status of the REQ request.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Retrieve detailed medical data associated with request REQ-12345.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "REQ-12345"},
                description="Read clinical indications and diagnosis.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Approve request REQ-12345 for the planned appendectomy.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12345"},
                description="Approve the request after successful verification.",
            ),
        ],
    ),

    # 8. Patient with relevant medical history (hypertension / allergies)
    Scenario(
        id=8,
        name="Review medical history and allergies before approval",
        description="Review Anna Brown's medical history and allergies for anesthesia risk before approving cholecystectomy.",
        permutation_type="History/Allergies -> Safety assessment -> Approve",
        patient_id="12346",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Retrieve the medical history and allergy history for patient Anna Brown before anesthesia.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "Anna Brown"},
                description="Check for potential anesthesia contraindications.",
            ),
            Turn(
                turn_id=2,
                user_prompt="History reviewed (no drug allergies). Approve request REQ-12346 for ward admission.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12346"},
                description="Safely approve the procedure.",
            ),
        ],
    ),

    # 9. Patient already approved - skip duplicate approval
    Scenario(
        id=9,
        name="Verify existing approval (no duplicate approval)",
        description="Patient 12346 already has admission approval. The agent checks status, notes the previous approval and directly assigns surgery.",
        permutation_type="Status -> Detect previous approval -> Surgery assignment",
        patient_id="12346",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Check whether patient 12346 already has approval for ward admission.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "12346"},
                description="Read the admission_approved=True flag.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Admission is already approved. Assign the planned surgery: Laparoscopic cholecystectomy.",
                expected_tools=["assign_patient_surgery"],
                expected_args={"surgery_name": "Laparoscopic cholecystectomy", "patient_id": "12346"},
                description="Assign surgery without unnecessary repeat approval.",
            ),
        ],
    ),

    # 10. Correct an incorrect patient ID during the conversation
    Scenario(
        id=10,
        name="Handle an incorrect patient ID and fall back to name",
        description="The user enters incorrect ID 99999. The agent cannot find the patient. The next turn corrects this to John Smith and approval succeeds.",
        permutation_type="Incorrect ID -> Handle missing data -> Search by name -> Approve",
        patient_id="12345",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Check the status of patient number 99999.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "99999"},
                description="Attempt to query a nonexistent patient.",
            ),
            Turn(
                turn_id=2,
                user_prompt="That number was a mistake. Search for patient John Smith's data.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "John Smith"},
                description="Successfully identify the patient using the correct name.",
            ),
            Turn(
                turn_id=3,
                user_prompt="ID 12345 was found. Approve this patient's admission request.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "12345"},
                description="Approve the correct patient after correcting the error.",
            ),
        ],
    ),

    # 11. Order specialized liver function tests before cholecystectomy
    Scenario(
        id=11,
        name="Specialized liver panel before gallbladder surgery",
        description="Before approving cholecystectomy, the agent verifies requirements and orders a dedicated liver enzyme panel (ALT, AST, bilirubin).",
        permutation_type="Data -> Specialized enzyme tests -> Approve",
        patient_id="12346",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Retrieve the medical documentation for patient 12346 and check the recommended laboratory panel.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "12346"},
                description="Read the liver function test requirement from the record.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Order Liver function tests for patient 12346 before assessment.",
                expected_tools=["assign_patient_labs"],
                expected_args={"lab_name": "Liver function tests", "patient_id": "12346"},
                description="Order a specific laboratory test.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Approve request REQ-12346 for cholecystectomy.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12346"},
                description="Approve after arranging appropriate liver diagnostic testing.",
            ),
        ],
    ),

    # 12. Verify bed and room after approval
    Scenario(
        id=12,
        name="Verify bed and room assignment after approval",
        description="Check data, approve the request and immediately verify the patient's assigned room.",
        permutation_type="Data -> Approve -> Room and bed verification",
        patient_id="12345",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Retrieve patient John Smith's data for admission.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "John Smith"},
                description="Identify patient data before room assignment.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Approve patient 12345 for admission to the General Surgery Ward.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "12345"},
                description="Approve with automatic bed assignment.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Retrieve the current status of patient 12345 to check the assigned room and bed numbers.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "12345"},
                description="Verify hospitalization status and patient location.",
            ),
        ],
    ),

    # 13. Cardiac assessment of an older patient (ECG and electrolytes)
    Scenario(
        id=13,
        name="Preoperative cardiac assessment of an older patient",
        description="Patient aged 68 (Theodore Lewis, 12349). Requires additional ECG and electrolyte testing before assessment.",
        permutation_type="Older patient -> Cardiac risk assessment -> ECG/Electrolytes -> Approve",
        patient_id="12349",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Retrieve patient Theodore Lewis's record and check his age and cardiovascular conditions.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "Theodore Lewis"},
                description="Assess the patient's age and comorbidities.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Order the safety panel: ECG, Electrolytes for patient 12349.",
                expected_tools=["assign_patient_labs"],
                expected_args={"lab_name": "ECG, Electrolytes", "patient_id": "12349"},
                description="Ensure anesthesia safety.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Approve request REQ-12349 for patient 12349's ward admission.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12349"},
                description="Approve while accounting for the geriatric profile.",
            ),
        ],
    ),

    # 14. Hold assessment due to missing paperwork
    Scenario(
        id=14,
        name="Assessment on hold - incomplete documentation",
        description="Patient 12350 presents without a medical referral. The agent checks status, identifies missing documentation and explains that it must be completed before approval.",
        permutation_type="Status -> Detect missing paperwork -> Hold assessment",
        patient_id="12350",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Check the request status for patient ID 12350.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "12350"},
                description="Detect 'Incomplete documentation' status.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Retrieve medical documentation details for patient 12350 to clarify what is missing.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "12350"},
                description="Identify the missing formal medical referral.",
            ),
        ],
    ),

    # 15. Change to a laparoscopic technique and approve
    Scenario(
        id=15,
        name="Modify the surgical technique to laparoscopy",
        description="Patient Peter Williams (12347). Assess for a less invasive surgical technique, approve the request and assign the procedure.",
        permutation_type="Data -> Approve -> Assign minimally invasive technique",
        patient_id="12347",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Retrieve medical data for patient 12347 to evaluate the surgical technique.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "12347"},
                description="Read the inguinal hernia diagnosis.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Approve request REQ-12347 for the General Surgery Ward.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12347"},
                description="Formally approve the ward stay.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Assign the optimized surgery: Inguinal hernia repair for patient 12347.",
                expected_tools=["assign_patient_surgery"],
                expected_args={"surgery_name": "Inguinal hernia repair", "patient_id": "12347"},
                description="Assign the surgical procedure in the schedule.",
            ),
        ],
    ),

    # 16. Urgent STAT blood typing before surgery
    Scenario(
        id=16,
        name="Arrange STAT blood typing before urgent surgery",
        description="A patient with an acute abdomen requires STAT blood typing before opening the abdominal cavity. The agent verifies requirements, orders blood testing and approves the request.",
        permutation_type="Urgent patient -> STAT blood typing -> Approve",
        patient_id="12345",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Check the required blood tests for patient 12345, who has been assessed for appendectomy.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "12345"},
                description="Verify the need for crossmatching and blood typing.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Order a STAT test: Blood typing for patient 12345.",
                expected_tools=["assign_patient_labs"],
                expected_args={"lab_name": "Blood typing", "patient_id": "12345"},
                description="Send an expedited order to the blood bank.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Approve urgent request REQ-12345 for the operating suite.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12345"},
                description="Approve after securing blood replacement products.",
            ),
        ],
    ),

    # 17. Coordinate two patients on one shift (multiple queries)
    Scenario(
        id=17,
        name="Coordinate two patients on one shift",
        description="The hospital coordinator first processes the urgent patient (12345) and approves the request, then checks the elective patient (12347) and approves the procedure.",
        permutation_type="Patient A (Data -> Approve) -> Patient B (Data -> Approve)",
        patient_id="12345",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Check data for the first patient, ID 12345 (urgent case).",
                expected_tools=["search_patient_data"],
                expected_args={"query": "12345"},
                description="Verify priority patient A.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Immediately approve the request for patient 12345.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "12345"},
                description="Approve patient A's request.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Now check the status of the second elective patient, ID 12347.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "12347"},
                description="Retrieve the status of the next patient, B, in the same session.",
            ),
            Turn(
                turn_id=4,
                user_prompt="Approve the request for the second patient, 12347.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "12347"},
                description="Approve patient B's request.",
            ),
        ],
    ),

    # 18. Patient taking anticoagulants (INR check)
    Scenario(
        id=18,
        name="Verify hemostasis in a patient taking anticoagulants",
        description="Patient taking anticoagulants (Stanley Wilson, 12351). Review history, order a coagulation panel (INR) and approve admission.",
        permutation_type="Anticoagulants -> Coagulation check (INR) -> Approve",
        patient_id="12351",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Retrieve patient Stanley Wilson's medical history and medication list before surgery.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "Stanley Wilson"},
                description="Identify oral anticoagulant use.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Order a hemostasis check: Coagulation panel PT, INR for patient 12351.",
                expected_tools=["assign_patient_labs"],
                expected_args={"lab_name": "Coagulation panel PT, INR", "patient_id": "12351"},
                description="Ensure coagulation parameters are checked.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Approve request REQ-12351 after arranging hemostasis diagnostic testing.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12351"},
                description="Approve surgical eligibility.",
            ),
        ],
    ),

    # 19. Verify the target ward and schedule
    Scenario(
        id=19,
        name="Verify the target ward and approve",
        description="Verify patient 12347's target ward, approve admission and directly assign surgery.",
        permutation_type="Status/Ward -> Approve -> Surgery",
        patient_id="12347",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Check the target ward in patient 12347's request.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "12347"},
                description="Verify the target ward within the hospital.",
            ),
            Turn(
                turn_id=2,
                user_prompt="General Surgery Ward confirmed. Approve request REQ-12347.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "REQ-12347"},
                description="Officially approve the request.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Assign surgery: Inguinal hernia repair for patient 12347.",
                expected_tools=["assign_patient_surgery"],
                expected_args={"surgery_name": "Inguinal hernia repair", "patient_id": "12347"},
                description="Schedule the surgery date.",
            ),
        ],
    ),

    # 20. Comprehensive end-to-end pathway (holistic admission process)
    Scenario(
        id=20,
        name="Comprehensive end-to-end pathway from admissions to the operating suite",
        description="Complete multistep process: register patient John Smith, search the medical record, order the full set of blood tests, approve the surgical ward request, assign an appendectomy and verify final readiness.",
        permutation_type="End-to-End: Arrival -> Search -> Tests -> Approve -> Surgery -> Final status",
        patient_id="12345",
        turns=[
            Turn(
                turn_id=1,
                user_prompt="Patient John Smith has arrived at the hospital. Retrieve his complete medical record.",
                expected_tools=["search_patient_data"],
                expected_args={"query": "John Smith"},
                description="Step 1: Verify identity and diagnosis.",
            ),
            Turn(
                turn_id=2,
                user_prompt="Order all required tests: CBC, Coagulation panel, Electrolytes for patient 12345.",
                expected_tools=["assign_patient_labs"],
                expected_args={"lab_name": "CBC, Coagulation panel, Electrolytes", "patient_id": "12345"},
                description="Step 2: Initiate laboratory testing.",
            ),
            Turn(
                turn_id=3,
                user_prompt="Approve the admission request for patient 12345 to the General Surgery Ward.",
                expected_tools=["approve_patient_request"],
                expected_args={"query": "12345"},
                description="Step 3: Authorize admission (approve).",
            ),
            Turn(
                turn_id=4,
                user_prompt="Assign surgery: Appendectomy for patient 12345.",
                expected_tools=["assign_patient_surgery"],
                expected_args={"surgery_name": "Appendectomy", "patient_id": "12345"},
                description="Step 4: Enter the surgery in the operative record.",
            ),
            Turn(
                turn_id=5,
                user_prompt="Retrieve the final status of patient 12345 to confirm readiness for surgery and the assigned bed.",
                expected_tools=["get_patient_status"],
                expected_args={"patient_id": "12345"},
                description="Step 5: Final hospitalization status report.",
            ),
        ],
    ),
]


def get_scenario(scenario_id: int) -> Optional[Scenario]:
    """Return the scenario with the given ID (1 through 20)."""
    for sc in SCENARIOS_DATABASE:
        if sc.id == scenario_id:
            return sc
    return None


def run_scenario(runner, scenario: Scenario, verbose: bool = False) -> Dict[str, Any]:
    """Run a scenario's complete conversation using the agent."""
    logs = []
    if hasattr(runner, "clear_history"):
        runner.clear_history()

    for turn in scenario.turns:
        step_res = runner.run(turn.user_prompt)
        invoked_tools = []
        if isinstance(step_res, dict) and "steps" in step_res:
            for s in step_res["steps"]:
                if s["type"] == "tool_calls":
                    for exec_item in s.get("executions", []):
                        invoked_tools.append(exec_item["tool"])
            final_ans = step_res.get("final_answer", "")
            steps_count = len(step_res["steps"])
        else:
            final_ans = str(step_res)
            steps_count = 1

        logs.append({
            "turn_id": turn.turn_id,
            "prompt": turn.user_prompt,
            "expected_tools": turn.expected_tools,
            "invoked_tools": invoked_tools,
            "final_answer": final_ans,
            "steps_count": steps_count,
        })

    return {
        "scenario_id": scenario.id,
        "name": scenario.name,
        "permutation_type": scenario.permutation_type,
        "turns": logs,
        "completed": True,
    }


def list_all_scenarios() -> List[Dict[str, Any]]:
    """Return a summary list of all 20 scenarios."""
    return [
        {
            "id": sc.id,
            "name": sc.name,
            "permutation_type": sc.permutation_type,
            "patient_id": sc.patient_id,
            "turns_count": len(sc.turns),
            "description": sc.description,
        }
        for sc in SCENARIOS_DATABASE
    ]
